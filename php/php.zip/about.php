<?php
	/**
	
	*/
<?php include 'header.php'; ?>
    <div class="clear"></div>
	<div id="post-container">
		<div class="post">
			<p>We are an ideas-sharing website, designed to get you in touch with the people who are thinking about tomorrow</p>
		</div>			
	</div>	
</div>
<?php include 'footer.php'; ?>
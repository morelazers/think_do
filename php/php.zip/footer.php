<?php
	/**
		Author: Mingkit Wong
	*/
?>
<div id="footer">
    <div id="links">
        <o><a href="about.php">About</a></p>
    </div>
    <div id="copyright">
	<p> Copyright &copy; Think.Do <script type="text/javascript"> document.write(dateObject.getFullYear());</script></p>
	</div>
</div>
</body>
</html>   
<?php include 'header.php'; ?>
    <div class="clear"></div>
    	<div id="post-container">
			<div class="post">
		        <?php include 'idea_form.php'; ?>
            </div>
        </div>
    </div>
<?php include 'footer.php'; ?>